# Mushroom Data Set

Data downloaded from [UCI Machine Learning Repository- Mushroom Data Set](http://archive.ics.uci.edu/ml/machine-learning-databases/mushroom).

## Data Set Information

Origin: 

Mushroom records drawn from The Audubon Society Field Guide to North American Mushrooms (1981). G. H. Lincoff (Pres.), New York: Alfred A. Knopf 

Donor: 

Jeff Schlimmer (Jeffrey.Schlimmer '@' a.gp.cs.cmu.edu)

Prediction task is to determine whether a mushroom is edible or poisonous.